(function () {
'use strict';

// Pont Android (simulé si on ouvre la page dans un navigateur)
var A = window.Android || {
  list: function () { return '[]'; }, state: function () { return '{"folders":0}'; },
  systemDark: function () { return false; }, pickFolder: function () {}, clearFolders: function () {},
  sync: function () {}, download: function () {}, shareWhatsApp: function () {}, share: function () {},
  delete: function () {}, pickFont: function () {}, customFont: function () { return ''; },
  setBars: function () {}, openBattery: function () {}
};

var $ = function (s) { return document.querySelector(s); };
var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); };

// ---------- Icônes SVG ----------
var I = {
  grid: '<rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/>',
  sliders: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 4v5h-5"/>',
  download: '<path d="M12 3v12m0 0l-4-4m4 4l4-4"/><path d="M5 20h14"/>',
  share: '<path d="M12 16V4m0 0L8 8m4-4l4 4"/><path d="M5 12v7h14v-7"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  play: '<path d="M8 5v14l11-7z" fill="currentColor" stroke="none"/>',
  chat: '<path d="M4 20l1.3-4.2A8 8 0 1 1 8.2 18.7z"/><path d="M9.5 9.5c.3 2 2 3.7 4 4l1.2-1.2-1.8-.9-.7.6c-.7-.3-1.3-.9-1.6-1.6l.6-.7-.9-1.8z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',
  type: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
  battery: '<rect x="3" y="8" width="16" height="9" rx="2"/><path d="M21 11v3"/><path d="M7 12h5"/>',
  ring: '<circle cx="12" cy="12" r="8"/><path d="M12 8v5m0 0l-2-2m2 2l2-2"/>'
};
function icon(n, c) {
  return '<svg class="ic ' + (c || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + I[n] + '</svg>';
}

// ---------- Préférences ----------
var ACC = {
  ciel: ['#2F8BFF', '#7CC0FF', 'Ciel'], azur: ['#00A8D6', '#6FE0F5', 'Azur'],
  indigo: ['#5B6CFF', '#A5AEFF', 'Indigo'], menthe: ['#1FB5A5', '#7CE6D9', 'Menthe']
};
var FONTS = {
  clash: ["'Clash Display', system-ui, sans-serif", 'Clash Display (par défaut)'],
  system: ["system-ui, -apple-system, Roboto, sans-serif", 'Système'],
  serif: ["Georgia, 'Times New Roman', serif", 'Serif'],
  mono: ["ui-monospace, 'Roboto Mono', monospace", 'Mono'],
  custom: ["'UserFont', 'Clash Display', sans-serif", 'Ma police']
};
var prefs = { theme: 'auto', accent: 'ciel', font: 'clash' };
try { Object.assign(prefs, JSON.parse(localStorage.getItem('prefs') || '{}')); } catch (e) {}
function savePrefs() { localStorage.setItem('prefs', JSON.stringify(prefs)); }

var S = { tab: 'home', filter: 'all', items: [], list: [], folders: 0, view: -1, ask: false, syncing: false,
          customName: localStorage.getItem('customFontName') || '' };

function isDark() { return prefs.theme === 'dark' || (prefs.theme === 'auto' && A.systemDark()); }

function loadCustomFont() {
  var b64 = A.customFont();
  var st = document.getElementById('customfont');
  if (!st) { st = document.createElement('style'); st.id = 'customfont'; document.head.appendChild(st); }
  st.textContent = b64 ? "@font-face{font-family:'UserFont';src:url(data:font/ttf;base64," + b64 + ")}" : '';
  if (!b64 && prefs.font === 'custom') { prefs.font = 'clash'; savePrefs(); }
}

function applyPrefs() {
  var d = isDark(), r = document.documentElement;
  r.dataset.theme = d ? 'dark' : 'light';
  var a = ACC[prefs.accent] || ACC.ciel;
  r.style.setProperty('--accent', a[0]);
  r.style.setProperty('--accent2', a[1]);
  r.style.setProperty('--font', (FONTS[prefs.font] || FONTS.clash)[0]);
  A.setBars(d ? '#0A1128' : '#F2F7FF', d);
}

// ---------- Données ----------
function left(it) {
  var ms = it.expiresAt - Date.now();
  if (ms <= 0) return 'Expiré';
  var h = ms / 36e5;
  if (h >= 24) { var d = Math.floor(h / 24), r = Math.floor(h % 24); return d + ' j' + (r ? ' ' + r + ' h' : ''); }
  if (h >= 1) return Math.floor(h) + ' h';
  return Math.max(1, Math.floor(ms / 6e4)) + ' min';
}

function filtered() {
  return S.items.filter(function (i) { return S.filter === 'all' || (S.filter === 'photo' ? i.type === 'image' : i.type === 'video'); });
}

function load() {
  try { S.items = JSON.parse(A.list()); } catch (e) { S.items = []; }
  try { S.folders = JSON.parse(A.state()).folders; } catch (e) { S.folders = 0; }
  S.list = filtered();
  if (S.view >= S.list.length) S.view = S.list.length - 1;
  renderMain();
  renderViewer();
}

// ---------- Rendu ----------
function renderTabs() {
  $('#tabs').innerHTML =
    '<button class="tab ' + (S.tab === 'home' ? 'on' : '') + '" data-act="tab" data-tab="home">' + icon('grid') + 'Statuts</button>' +
    '<button class="tab ' + (S.tab === 'settings' ? 'on' : '') + '" data-act="tab" data-tab="settings">' + icon('sliders') + 'Réglages</button>';
}

function home() {
  var n = S.items.length;
  var h = '<div class="pad"><div class="toprow"><div><h1>Statuts</h1><div class="sub">' +
    (n ? n + (n > 1 ? ' gardés' : ' gardé') : 'Rien de gardé') + ' · 4 jours max</div></div>' +
    '<button class="round ' + (S.syncing ? 'spin' : '') + '" data-act="sync">' + icon('refresh') + '</button></div></div>';
  if (!S.folders) {
    h += '<div class="hero-card"><div class="big">' + icon('ring') + '</div><h2>Connecte WhatsApp</h2>' +
      '<p>Autorise le dossier des statuts une seule fois. Ensuite, chaque statut que tu regardes est gardé ici pendant 4 jours.</p>' +
      '<button class="btn" data-act="folder" data-b="0">' + icon('folder') + ' Autoriser WhatsApp</button>' +
      '<button class="btn ghost" data-act="folder" data-b="1">' + icon('folder') + ' WhatsApp Business</button></div>';
  }
  h += '<div class="seg">' +
    [['all', 'Tout'], ['photo', 'Photos'], ['video', 'Vidéos']].map(function (f) {
      return '<button class="' + (S.filter === f[0] ? 'on' : '') + '" data-act="filter" data-f="' + f[0] + '">' + f[1] + '</button>';
    }).join('') + '</div>';
  var list = filtered();
  if (!list.length) {
    h += '<div class="empty">' + icon('image') + '<div>' +
      (S.folders ? 'Aucun statut pour l’instant.<br>Regarde des statuts dans WhatsApp, ils apparaîtront ici.' : 'Connecte WhatsApp pour commencer.') + '</div></div>';
  } else {
    h += '<div class="grid">' + list.map(function (it, i) {
      return '<button class="tile" data-act="open" data-i="' + i + '">' +
        (it.thumb ? '<img loading="lazy" src="' + esc(it.thumb) + '">' : icon(it.type === 'video' ? 'play' : 'image')) +
        (it.type === 'video' ? '<span class="vbadge">' + icon('play') + '</span>' : '') +
        '<span class="chip">' + icon('clock') + left(it) + '</span></button>';
    }).join('') + '</div>';
  }
  return h + '<div class="sig">Fait par <b>@fabro</b></div>';
}

function settings() {
  var h = '<div class="pad"><h1>Réglages</h1></div>';
  h += '<div class="gt">Apparence</div><div class="seg">' +
    [['auto', 'Auto'], ['light', 'Jour'], ['dark', 'Nuit']].map(function (t) {
      return '<button class="' + (prefs.theme === t[0] ? 'on' : '') + '" data-act="theme" data-v="' + t[0] + '">' + t[1] + '</button>';
    }).join('') + '</div>';
  h += '<div class="group"><div class="row"><span class="grow">Couleur</span><div class="dots">' +
    Object.keys(ACC).map(function (k) {
      return '<button class="dot ' + (prefs.accent === k ? 'on' : '') + '" style="background:' + ACC[k][0] + '" data-act="accent" data-v="' + k + '"></button>';
    }).join('') + '</div></div></div>';
  h += '<div class="gt">Police</div><div class="group">' +
    Object.keys(FONTS).filter(function (k) { return k !== 'custom' || S.customName; }).map(function (k) {
      var label = k === 'custom' ? 'Ma police · ' + esc(S.customName) : FONTS[k][1];
      return '<button class="row" data-act="font" data-v="' + k + '" style="font-family:' + FONTS[k][0].replace(/"/g, '') + '">' +
        icon('type') + '<span class="grow">' + label + '</span>' + (prefs.font === k ? icon('check') : '') + '</button>';
    }).join('') +
    '<button class="row" data-act="pickfont">' + icon('download') + '<span class="grow">Importer une police…</span></button></div>';
  h += '<div class="gt">WhatsApp</div><div class="group">' +
    '<button class="row" data-act="folder" data-b="0">' + icon('folder') + '<span class="grow">Ajouter WhatsApp</span></button>' +
    '<button class="row" data-act="folder" data-b="1">' + icon('folder') + '<span class="grow">Ajouter WhatsApp Business</span></button>' +
    '<div class="row">' + icon('check') + '<span class="grow">Dossiers connectés</span><span class="val">' + S.folders + '</span></div>' +
    (S.folders ? '<button class="row danger" data-act="clearfolders">' + icon('trash') + '<span class="grow">Retirer les dossiers</span></button>' : '') + '</div>';
  h += '<div class="gt">Sauvegarde automatique</div><div class="group">' +
    '<button class="row" data-act="sync">' + icon('refresh') + '<span class="grow">Synchroniser maintenant</span></button>' +
    '<button class="row" data-act="battery">' + icon('battery') + '<span class="grow">Autoriser en arrière-plan</span></button></div>' +
    '<div class="note">L’appli copie les statuts vus toutes les ~15 minutes. Pour que ça marche écran éteint, mets Statuts en « Non optimisé » dans les réglages batterie.</div>';
  return h + '<div class="sig">Statuts 1.0 · Fait par <b>@fabro</b></div>';
}

function renderMain() {
  var m = $('#main'), y = m.scrollTop;
  m.innerHTML = S.tab === 'home' ? home() : settings();
  m.scrollTop = y;
  renderTabs();
}

function renderViewer() {
  var v = $('#viewer');
  if (S.view < 0 || !S.list[S.view]) { v.className = ''; v.innerHTML = ''; return; }
  var it = S.list[S.view];
  v.className = 'open';
  v.innerHTML =
    '<div class="vtop"><button class="round" data-act="close">' + icon('close') + '</button>' +
    '<div class="vinfo"><b>' + (it.type === 'video' ? 'Vidéo' : 'Photo') + '</b><span>Expire dans ' + left(it) + '</span></div>' +
    '<div class="vcount">' + (S.view + 1) + ' / ' + S.list.length + '</div></div>' +
    '<div class="vmedia">' + (it.type === 'video'
      ? '<video src="' + esc(it.url) + '" controls autoplay playsinline loop></video>'
      : '<img src="' + esc(it.url) + '">') + '</div>' +
    '<div class="vbar">' +
    '<button data-act="dl">' + icon('download') + 'Télécharger</button>' +
    '<button class="wa" data-act="wa">' + icon('chat') + 'WhatsApp</button>' +
    '<button data-act="share">' + icon('share') + 'Partager</button>' +
    '<button class="del" data-act="ask">' + icon('trash') + 'Supprimer</button></div>' +
    (S.ask ? '<div class="sheet"><p>Supprimer ce statut de l’appli ?</p><button class="del" data-act="del">Supprimer</button><button data-act="cancel">Annuler</button></div>' : '');
}

function renderAll() { renderMain(); renderViewer(); }

// ---------- Actions ----------
function go(d) {
  var n = S.view + d;
  if (n < 0 || n >= S.list.length) return;
  S.view = n; S.ask = false; renderViewer();
}

function closeViewer() { S.view = -1; S.ask = false; renderViewer(); }

document.addEventListener('click', function (e) {
  var t = e.target.closest('[data-act]');
  if (!t) return;
  var d = t.dataset, cur = S.list[S.view];
  switch (d.act) {
    case 'tab': S.tab = d.tab; renderMain(); break;
    case 'filter': S.filter = d.f; S.list = filtered(); renderMain(); break;
    case 'open': S.list = filtered(); S.view = parseInt(d.i, 10); S.ask = false; renderViewer(); break;
    case 'close': closeViewer(); break;
    case 'sync': S.syncing = true; renderMain(); A.sync(); break;
    case 'folder': A.pickFolder(d.b === '1'); break;
    case 'clearfolders': A.clearFolders(); load(); toast('Dossiers retirés'); break;
    case 'dl': if (cur) A.download(cur.name); break;
    case 'wa': if (cur) A.shareWhatsApp(cur.name); break;
    case 'share': if (cur) A.share(cur.name); break;
    case 'ask': S.ask = true; renderViewer(); break;
    case 'cancel': S.ask = false; renderViewer(); break;
    case 'del':
      if (cur) {
        A.delete(cur.name);
        S.items = S.items.filter(function (i) { return i.name !== cur.name; });
        S.list = filtered(); S.ask = false;
        if (!S.list.length) S.view = -1; else if (S.view >= S.list.length) S.view = S.list.length - 1;
        renderAll(); toast('Statut supprimé');
      }
      break;
    case 'theme': prefs.theme = d.v; savePrefs(); applyPrefs(); renderMain(); break;
    case 'accent': prefs.accent = d.v; savePrefs(); applyPrefs(); renderMain(); break;
    case 'font': prefs.font = d.v; savePrefs(); applyPrefs(); renderMain(); break;
    case 'pickfont': A.pickFont(); break;
    case 'battery': A.openBattery(); break;
  }
});

// Balayage gauche / droite sur les photos
var tx = 0, onImg = false;
document.addEventListener('touchstart', function (e) { tx = e.touches[0].clientX; onImg = e.target.tagName === 'IMG' && !!e.target.closest('.vmedia'); }, { passive: true });
document.addEventListener('touchend', function (e) {
  if (S.view < 0 || !onImg) return;
  var dx = e.changedTouches[0].clientX - tx;
  if (Math.abs(dx) > 70) go(dx < 0 ? 1 : -1);
}, { passive: true });

// ---------- Rappels depuis Android ----------
function toast(m) {
  var t = $('#toast');
  t.textContent = m; t.classList.add('show');
  clearTimeout(window._tt);
  window._tt = setTimeout(function () { t.classList.remove('show'); }, 2200);
}
window.toast = toast;
window.onSynced = function (n) {
  S.syncing = false; load();
  if (n > 0) toast(n + (n > 1 ? ' nouveaux statuts gardés' : ' nouveau statut gardé'));
};
window.onFolderAdded = function () { toast('Dossier ajouté'); load(); };
window.onFontImported = function (name) {
  S.customName = name; localStorage.setItem('customFontName', name);
  loadCustomFont(); prefs.font = 'custom'; savePrefs(); applyPrefs(); renderMain(); toast('Police importée');
};
window.onSystemTheme = function () { if (prefs.theme === 'auto') { applyPrefs(); } };
window.onResume = function () { load(); A.sync(); };
window.onBack = function () {
  if (S.ask) { S.ask = false; renderViewer(); return true; }
  if (S.view >= 0) { closeViewer(); return true; }
  if (S.tab !== 'home') { S.tab = 'home'; renderMain(); return true; }
  return false;
};

// ---------- Démarrage ----------
loadCustomFont();
applyPrefs();
load();
setInterval(function () { if (S.view < 0) renderMain(); }, 60000);
})();
