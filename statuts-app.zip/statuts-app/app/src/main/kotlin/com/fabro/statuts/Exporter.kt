package com.fabro.statuts

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import androidx.core.content.FileProvider

/** Téléchargement vers la galerie et partage (WhatsApp ou autre). */
object Exporter {

    fun saveToGallery(ctx: Context, name: String): Boolean {
        val f = StatusStore.file(ctx, name)
        if (!f.exists()) return false
        val video = StatusStore.isVideo(f.name)
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "Statut_" + f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, StatusStore.mime(f.name))
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                if (video) "Movies/Statuts" else "Pictures/Statuts"
            )
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val resolver = ctx.contentResolver
        val uri = resolver.insert(collection, values) ?: return false
        return try {
            resolver.openOutputStream(uri)?.use { out ->
                f.inputStream().use { it.copyTo(out) }
            }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            true
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            false
        }
    }

    /** pkg = "com.whatsapp" pour WhatsApp direct, null pour le menu de partage Android. */
    fun share(act: Activity, name: String, pkg: String?) {
        val f = StatusStore.file(act, name)
        if (!f.exists()) return
        val uri = FileProvider.getUriForFile(act, act.packageName + ".fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = StatusStore.mime(f.name)
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (pkg != null) setPackage(pkg)
        }
        try {
            act.startActivity(if (pkg != null) i else Intent.createChooser(i, null))
        } catch (e: ActivityNotFoundException) {
            if (pkg != null) share(act, name, null)
        }
    }
}
