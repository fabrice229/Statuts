package com.fabro.statuts

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.WindowCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {

    lateinit var web: WebView

    companion object {
        const val REQ_FOLDER = 101
        const val REQ_FONT = 102
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(getColor(R.color.bg))
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        s.mediaPlaybackRequiresUserGesture = false
        disableForceDark(s)

        web.addJavascriptInterface(Bridge(this), "Android")
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/www/index.html")

        val req = PeriodicWorkRequestBuilder<StatusSyncWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("sync", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    @Suppress("DEPRECATION")
    private fun disableForceDark(s: WebSettings) {
        if (Build.VERSION.SDK_INT < 33) s.forceDark = WebSettings.FORCE_DARK_OFF
    }

    override fun onResume() {
        super.onResume()
        js("window.onResume&&window.onResume()")
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        js("window.onSystemTheme&&window.onSystemTheme()")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBack&&window.onBack())===true") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    // ---------- Utilitaires appelés par le pont ----------
    fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    fun toast(msg: String) {
        js("window.toast&&window.toast(" + JSONObject.quote(msg) + ")")
    }

    fun setBars(bg: String, dark: Boolean) {
        runOnUiThread {
            val c = Color.parseColor(bg)
            window.statusBarColor = c
            window.navigationBarColor = c
            web.setBackgroundColor(c)
            val ctl = WindowCompat.getInsetsController(window, window.decorView)
            ctl.isAppearanceLightStatusBars = !dark
            ctl.isAppearanceLightNavigationBars = !dark
        }
    }

    fun syncAsync() {
        Thread {
            val n = try {
                StatusStore.sync(this)
            } catch (e: Exception) {
                0
            }
            js("window.onSynced&&window.onSynced(" + n + ")")
        }.start()
    }

    fun pickFolder(business: Boolean) {
        val path = if (business) {
            "primary:Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses"
        } else {
            "primary:Android/media/com.whatsapp/WhatsApp/Media/.Statuses"
        }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
            )
            putExtra(
                DocumentsContract.EXTRA_INITIAL_URI,
                DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", path)
            )
        }
        startActivityForResult(i, REQ_FOLDER)
    }

    fun pickFont() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, REQ_FONT)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri: Uri = data.data ?: return
        when (requestCode) {
            REQ_FOLDER -> {
                StatusStore.addTree(this, uri)
                js("window.onFolderAdded&&window.onFolderAdded()")
                syncAsync()
            }
            REQ_FONT -> Thread {
                try {
                    var name = "Ma police"
                    contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
                    }
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes == null || bytes.size > 5_000_000) {
                        toast("Police illisible ou trop lourde")
                    } else {
                        File(filesDir, "custom_font").writeBytes(bytes)
                        js("window.onFontImported&&window.onFontImported(" + JSONObject.quote(name) + ")")
                    }
                } catch (e: Exception) {
                    toast("Impossible d’importer cette police")
                }
            }.start()
        }
    }
}
