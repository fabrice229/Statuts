package com.fabro.statuts

import android.content.Intent
import android.content.res.Configuration
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.io.File

/** Pont JavaScript <-> Kotlin (exposé à l'interface sous le nom `Android`). */
class Bridge(private val act: MainActivity) {

    @JavascriptInterface
    fun list(): String = StatusStore.list(act)

    @JavascriptInterface
    fun state(): String = JSONObject()
        .put("folders", StatusStore.trees(act).size)
        .put("days", StatusStore.RETENTION_DAYS)
        .toString()

    @JavascriptInterface
    fun systemDark(): Boolean =
        (act.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    @JavascriptInterface
    fun pickFolder(business: Boolean) {
        act.runOnUiThread { act.pickFolder(business) }
    }

    @JavascriptInterface
    fun clearFolders() {
        StatusStore.clearTrees(act)
    }

    @JavascriptInterface
    fun sync() {
        act.syncAsync()
    }

    @JavascriptInterface
    fun download(name: String) {
        Thread {
            val ok = Exporter.saveToGallery(act, name)
            act.toast(if (ok) "Enregistré dans la galerie" else "Échec de l’enregistrement")
        }.start()
    }

    @JavascriptInterface
    fun shareWhatsApp(name: String) {
        act.runOnUiThread { Exporter.share(act, name, "com.whatsapp") }
    }

    @JavascriptInterface
    fun share(name: String) {
        act.runOnUiThread { Exporter.share(act, name, null) }
    }

    @JavascriptInterface
    fun delete(name: String) {
        StatusStore.delete(act, name)
    }

    @JavascriptInterface
    fun pickFont() {
        act.runOnUiThread { act.pickFont() }
    }

    @JavascriptInterface
    fun customFont(): String {
        val f = File(act.filesDir, "custom_font")
        return if (f.exists()) Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) else ""
    }

    @JavascriptInterface
    fun setBars(bg: String, dark: Boolean) {
        act.setBars(bg, dark)
    }

    @JavascriptInterface
    fun openBattery() {
        act.runOnUiThread {
            try {
                act.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
            }
        }
    }
}
