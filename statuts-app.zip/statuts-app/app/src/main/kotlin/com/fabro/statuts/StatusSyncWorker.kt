package com.fabro.statuts

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

/** Tâche de fond : copie les statuts vus toutes les ~15 min, avant que WhatsApp ne les efface. */
class StatusSyncWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try {
            StatusStore.sync(applicationContext)
        } catch (e: Exception) {
        }
        return Result.success()
    }
}
