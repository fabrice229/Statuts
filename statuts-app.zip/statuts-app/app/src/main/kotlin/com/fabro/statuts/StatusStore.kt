package com.fabro.statuts

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Stockage local des statuts : copie depuis WhatsApp, miniatures, purge à 4 jours. */
object StatusStore {
    const val RETENTION_DAYS = 4
    private const val RETENTION_MS = RETENTION_DAYS * 24L * 3600L * 1000L
    private val VIDEO_EXT = setOf("mp4", "3gp", "mkv", "webm", "mov")
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "gif")
    private val lock = Any()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("statuts", Context.MODE_PRIVATE)

    fun dir(ctx: Context): File = File(ctx.filesDir, "statuses").also { it.mkdirs() }
    private fun thumbDir(ctx: Context): File = File(ctx.filesDir, "thumbs").also { it.mkdirs() }
    fun file(ctx: Context, name: String): File = File(dir(ctx), File(name).name)
    private fun thumbFile(ctx: Context, f: File) = File(thumbDir(ctx), f.name + ".jpg")

    private fun ext(name: String) = name.substringAfterLast('.', "").lowercase()
    fun isVideo(name: String) = ext(name) in VIDEO_EXT
    private fun isMedia(name: String) = ext(name) in VIDEO_EXT || ext(name) in IMAGE_EXT
    fun mime(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(name))
            ?: if (isVideo(name)) "video/*" else "image/*"

    // ---------- Dossiers WhatsApp autorisés (SAF) ----------
    fun trees(ctx: Context): Set<String> =
        prefs(ctx).getStringSet("trees", emptySet()) ?: emptySet()

    fun addTree(ctx: Context, uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
        }
        val s = trees(ctx).toMutableSet()
        s.add(uri.toString())
        prefs(ctx).edit().putStringSet("trees", s).apply()
    }

    fun clearTrees(ctx: Context) {
        prefs(ctx).edit().remove("trees").apply()
    }

    private fun ignored(ctx: Context): Set<String> =
        prefs(ctx).getStringSet("ignored", emptySet()) ?: emptySet()

    private fun findStatuses(root: DocumentFile, depth: Int): DocumentFile? {
        if (root.name == ".Statuses") return root
        if (depth <= 0) return null
        val children = root.listFiles()
        for (c in children) {
            if (c.isDirectory && c.name == ".Statuses") return c
        }
        for (c in children) {
            if (c.isDirectory) {
                val r = findStatuses(c, depth - 1)
                if (r != null) return r
            }
        }
        return null
    }

    // ---------- Synchronisation ----------
    /** Copie les nouveaux statuts, purge les anciens. Retourne le nombre de nouveaux statuts. */
    fun sync(ctx: Context): Int = synchronized(lock) {
        var added = 0
        val skip = ignored(ctx)
        for (s in trees(ctx)) {
            try {
                val root = DocumentFile.fromTreeUri(ctx, Uri.parse(s)) ?: continue
                val st = findStatuses(root, 4) ?: continue
                for (f in st.listFiles()) {
                    val name = f.name ?: continue
                    if (name.startsWith(".") || !isMedia(name) || name in skip) continue
                    val out = File(dir(ctx), name)
                    if (out.exists()) continue
                    val tmp = File(dir(ctx), "$name.part")
                    try {
                        ctx.contentResolver.openInputStream(f.uri)?.use { input ->
                            FileOutputStream(tmp).use { input.copyTo(it) }
                        }
                        if (tmp.exists() && tmp.renameTo(out)) {
                            ensureThumb(ctx, out)
                            added++
                        }
                    } catch (e: Exception) {
                        tmp.delete()
                    }
                }
            } catch (e: Exception) {
            }
        }
        purge(ctx)
        WidgetProvider.refresh(ctx)
        added
    }

    fun purge(ctx: Context) {
        val limit = System.currentTimeMillis() - RETENTION_MS
        dir(ctx).listFiles()?.forEach {
            if (it.lastModified() < limit) {
                it.delete()
                thumbFile(ctx, it).delete()
            }
        }
        thumbDir(ctx).listFiles()?.forEach {
            if (!File(dir(ctx), it.name.removeSuffix(".jpg")).exists()) it.delete()
        }
    }

    fun delete(ctx: Context, name: String) {
        val f = file(ctx, name)
        f.delete()
        thumbFile(ctx, f).delete()
        val s = ignored(ctx).toMutableSet()
        s.add(f.name)
        prefs(ctx).edit().putStringSet("ignored", s).apply()
        WidgetProvider.refresh(ctx)
    }

    // ---------- Liste & miniatures ----------
    fun files(ctx: Context): List<File> =
        (dir(ctx).listFiles() ?: emptyArray())
            .filter { it.isFile && !it.name.endsWith(".part") }
            .sortedByDescending { it.lastModified() }

    fun ensureThumb(ctx: Context, f: File): File? {
        val t = thumbFile(ctx, f)
        if (t.exists()) return t
        val bmp: Bitmap? = try {
            if (isVideo(f.name)) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(f.absolutePath)
                    r.getFrameAtTime(0)
                } finally {
                    r.release()
                }
            } else {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.absolutePath, o)
                var sample = 1
                while (o.outWidth / sample > 800) sample *= 2
                BitmapFactory.decodeFile(
                    f.absolutePath,
                    BitmapFactory.Options().apply { inSampleSize = sample }
                )
            }
        } catch (e: Exception) {
            null
        }
        if (bmp == null) return null
        return try {
            FileOutputStream(t).use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            t
        } catch (e: Exception) {
            null
        }
    }

    fun list(ctx: Context): String {
        val arr = JSONArray()
        for (f in files(ctx)) {
            val thumb = ensureThumb(ctx, f)
            arr.put(
                JSONObject()
                    .put("name", f.name)
                    .put("type", if (isVideo(f.name)) "video" else "image")
                    .put("url", Uri.fromFile(f).toString())
                    .put("thumb", if (thumb != null) Uri.fromFile(thumb).toString() else "")
                    .put("savedAt", f.lastModified())
                    .put("expiresAt", f.lastModified() + RETENTION_MS)
                    .put("size", f.length())
            )
        }
        return arr.toString()
    }
}
