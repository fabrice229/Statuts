package com.fabro.statuts

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.ThumbnailUtils
import android.view.View
import android.widget.RemoteViews
import java.io.File

class WidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(context))
    }

    companion object {
        fun refresh(ctx: Context) {
            try {
                val m = AppWidgetManager.getInstance(ctx)
                val ids = m.getAppWidgetIds(ComponentName(ctx, WidgetProvider::class.java))
                for (id in ids) m.updateAppWidget(id, build(ctx))
            } catch (e: Exception) {
            }
        }

        private fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            val files = StatusStore.files(ctx)
            val n = files.size
            rv.setTextViewText(
                R.id.w_count,
                when (n) {
                    0 -> "Aucun statut"
                    1 -> "1 statut"
                    else -> "$n statuts"
                }
            )
            val thumb = files.firstOrNull()?.let { StatusStore.ensureThumb(ctx, it) }
            val bmp = thumb?.let { rounded(it) }
            if (bmp != null) {
                rv.setImageViewBitmap(R.id.w_thumb, bmp)
                rv.setViewVisibility(R.id.w_thumb, View.VISIBLE)
            } else {
                rv.setViewVisibility(R.id.w_thumb, View.GONE)
            }
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.w_root, pi)
            return rv
        }

        private fun rounded(f: File): Bitmap? {
            val src = BitmapFactory.decodeFile(f.absolutePath) ?: return null
            val size = 192
            val sq = ThumbnailUtils.extractThumbnail(src, size, size)
            val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = BitmapShader(sq, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            Canvas(out).drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), 36f, 36f, p)
            return out
        }
    }
}
