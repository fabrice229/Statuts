# Statuts — @fabro

Appli Android qui garde les statuts WhatsApp que tu regardes pendant 4 jours maximum.
Style iOS, bleu ciel / bleu nuit, mode jour/nuit, widget, partage direct vers WhatsApp,
police Clash Display par défaut (modifiable dans Réglages).

## Obtenir le fichier APK (rien à installer sur ton PC)

1. Crée un dépôt GitHub (privé si tu veux) et envoie-y tout ce dossier.
2. Onglet **Actions** → **Build APK** → le build démarre tout seul (ou « Run workflow »).
3. Quand c'est vert, ouvre l'exécution et télécharge l'artefact **statuts-apk** (un zip contenant `app-debug.apk`).

## Installer sur le téléphone

Active le débogage USB, branche le téléphone, puis dans cmd :

    adb install -r app-debug.apk

## Premier lancement

1. Ouvre l'appli → **Autoriser WhatsApp** → dans le sélecteur de dossier, appuie sur **Utiliser ce dossier**.
   (Le sélecteur s'ouvre directement sur `Android/media/com.whatsapp/WhatsApp/Media/.Statuses`.)
2. Regarde des statuts dans WhatsApp : ils sont copiés toutes les ~15 min et à chaque ouverture de l'appli.
3. Réglages → **Autoriser en arrière-plan** pour que la copie continue écran éteint.

## Notes

- Android 10 ou plus. Aucun accès internet, aucune permission dangereuse.
- Statuts supprimés à la main : ils ne sont pas recopiés. Les autres disparaissent après 4 jours.
- Compiler en local (optionnel) : Android Studio ou `gradle assembleDebug` avec JDK 17 et le SDK Android 34.
- Police : Clash Display (licence FFL, voir `app/src/main/assets/www/fonts/LICENSE-FFL.txt`).
